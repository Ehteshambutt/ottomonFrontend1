import React from 'react'

const Accessories = () => {
    return (
        <div><h1>Accessories</h1></div>
    )
}

export default Accessories